import subprocess
W,H=720,1450
cfg={
 'v1':dict(name='1-bron',crop=(378,761,0,45),blurs=[],segs=[(0.8,5.2),(5.9,16.4),(22.0,31.3),(33.6,38.3)]),
 'v2':dict(name='3-proverka-vybor-iz-chatov',crop=(572,1152,0,62),
   blurs=[(10.85,14.0,0,220,572,98),(10.85,14.0,0,414,572,800),
          (14.0,15.8,0,220,572,98),(14.0,15.8,0,414,572,54),(14.0,15.8,0,808,572,406),(14.0,15.8,0,468,26,340),(14.0,15.8,550,468,22,340),
          (29.6,32.0,0,844,572,276)],
   segs=[(3.0,7.0),(10.2,15.7),(16.3,19.5),(24.3,31.8)]),
 'v3':dict(name='2-konkurs',crop=(572,1152,0,62),blurs=[],segs=[(0.0,3.3),(6.0,16.5),(20.6,23.6)]),
 'v4':dict(name='4-proverka-peresylka',crop=(572,1152,0,62),blurs=[],segs=[(1.5,6.8),(14.0,16.75),(20.0,26.6)]),
}
for v,c in cfg.items():
    f=[];last='0:v'
    for i,(a,b,x,y,w,h) in enumerate(c['blurs']):
        f.append(f"[{last}]split[m{i}][s{i}];[s{i}]crop={w}:{h}:{x}:{y},{'boxblur=5:3' if w<60 else 'gblur=sigma=22'}[b{i}];[m{i}][b{i}]overlay={x}:{y}:enable='between(t,{a},{b})'[o{i}]")
        last=f"o{i}"
    cw,ch,cx,cy=c['crop']
    n=len(c['segs'])
    f.append(f"[{last}]crop={cw}:{ch}:{cx}:{cy},scale={W}:{H}:flags=lanczos,setsar=1,fps=30,split={n}"+''.join(f"[p{k}]" for k in range(n)))
    for k,(a,b) in enumerate(c['segs']):
        f.append(f"[p{k}]trim={a}:{b},setpts=PTS-STARTPTS[t{k}]")
    f.append(''.join(f"[t{k}]" for k in range(n))+f"concat=n={n}:v=1:a=0[out]")
    cmd=['ffmpeg','-v','error','-y','-i',f'src/{v}.mp4','-filter_complex',';'.join(f).replace('[0:v]','[0:v]'),'-map','[out]','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',f"out/{c['name']}.mp4"]
    fc=';'.join(f)
    fc=fc.replace('[0:v]split','[0:v]split',1)
    cmd[cmd.index('-filter_complex')+1]=fc.replace("[0:v]","[0:v]")
    subprocess.run(cmd,check=True)
    print(c['name'],subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',f"out/{c['name']}.mp4"],capture_output=True,text=True).stdout.strip())
